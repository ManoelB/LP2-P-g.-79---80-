import java.util.Scanner;

public class Q6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite a nota da primeira prova: ");
            Double prova1 = scanner.nextDouble();
        System.out.println("Digite a nota da segunda prova: ");
            Double prova2 = scanner.nextDouble();
        System.out.println("Digite a nota do trabalho: ");
            Double trab = scanner.nextDouble();
        
        Double media;
        media = (prova1 + prova2 + trab)/3;

        if (media >= 7) {
            System.out.println("Você está aprovado!");
        } else {
            System.out.println("Você está reprovado!");
        }
        scanner.close();
    }
    }

