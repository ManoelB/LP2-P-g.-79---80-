import java.util.Scanner;

public class Q2 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
            System.out.println("Qual distância você deseja percorrer em km? ");
                double distancia = scanner.nextDouble();
            System.out.println("Qual o preço do litro da gasolina? ");
                double preco = scanner.nextDouble();
            double kmh = 12.00;
            double gaso = distancia / kmh;
            double custo = gaso * preco;
         System.out.println("A quantidade total de gasolina necessária para o percurso é de " + gaso + "litros.");
         System.out.println("O gasto necessário de gasolina para percorrer o percurso é de R$" + custo + "." );
        
    }
} 