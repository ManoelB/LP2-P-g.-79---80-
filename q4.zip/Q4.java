import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite a temperatura do paciente: ");
        Double temp = scanner.nextDouble();

        if (temp > 37) {
            System.out.println("O paciente está com febre.");
        } else {
            System.out.println("O paciente não está com febre.");
        }
        
        scanner.close();
    }
}
