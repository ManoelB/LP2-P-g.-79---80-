import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o primeiro número: ");
            Double num1 = scanner.nextDouble();
        System.out.println("Digite o segundo número, diferente do primeiro: ");
            Double num2 = scanner.nextDouble();

        if (num1 > num2) {
            System.out.println( num1 + " é maior que " + num2);
        } else {
            System.out.println( num2 + " é maior que " + num1);
        }
        scanner.close();
    }
    }

