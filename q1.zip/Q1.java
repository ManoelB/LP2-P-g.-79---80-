import java.util.Scanner;

public class Q1{
    public static void main(String[] args){
        try (Scanner teclado = new Scanner (System.in)) {
            float resultado;
            System.out.println("Quantas horas você trabalha por mês? ");
                int horas = teclado.nextInt();
            resultado = horas * 20;
        
            System.out.println("Você recebe " + resultado + " reais por mês.");    
        }
    }
} 