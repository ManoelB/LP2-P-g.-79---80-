import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o primeiro valor: ");
            Double va1 = scanner.nextDouble();
        System.out.println("Digite o segundo valor: ");
            Double va2 = scanner.nextDouble();

        
        Double soma = va1 + va2;

        if (soma > 10) {
            System.out.println(soma);
        } else {
            System.out.println("A soma dos dois valores menor que 10");
        }
        scanner.close();
    }
    }

