import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o valor do raio da circunferência (em cm): ");
            Double raio = scanner.nextDouble();
        
        Double pi = 3.14;
        Double A = pi * (raio * raio);
        
        System.out.println("O valor da circunferência é: " + A "cm²");

        }
    }

