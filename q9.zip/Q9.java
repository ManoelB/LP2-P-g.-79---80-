import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o valor da sua hora aula: ");
            Double hoau = scanner.nextDouble();
        System.out.println("Digite a quantidade de horas trabalhadas por mês: ");
            Double homes = scanner.nextDouble();
        System.out.println("Digite o valor do percentual de desconto do INSS: ");
            Double inss = scanner.nextDouble();
        
        Double bruto = hoau * homes;
        Double descinss = (inss / 100) * bruto;
        Double liq = bruto - descinss;
        
        System.out.println("O seu salário bruto é R$" + bruto + ".");
        System.out.println("O seu salário liquido é R$" + liq + ".");
        }
    }

